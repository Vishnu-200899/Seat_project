/* ###################################################################
**     Filename    : main.c
**     Processor   : S32K1xx
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.00
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including necessary module. Cpu.h contains other modules needed for compiling.*/
#include "Cpu.h"
#include "pin_mux.h"
#include "flexTimer_pwm1.h"
#include "clockMan1.h"
  volatile int exit_code = 0;

/* User includes (#include below this line is not maintained by Processor Expert) */

#include <stdint.h>
#include <stdbool.h>

/***********************************
 * @brief: Wait for a number of cycles
 * @param nbOfCycles is number of cycles to be waited for
 ***********************************/
void delayCycles(volatile uint32_t cycles)
{
    while (cycles--)
    {
    }
}
#define PWM_MAX   4800U

/*! 
  \brief The main function for the project.
  \details The startup initialization sequence is the following:
 * - startup asm routine
 * - main()
*/
int main(void)
{
  /* Write your local variable definition here */
	 /* Variables used to store PWM duty cycle */
	ftm_state_t ftmStateStruct;
	uint16_t dutyCycle = PWM_MAX / 2;
	bool increaseDutyCycle = false;
  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  #ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();                   /* Initialization of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */

/* Initialize and configure clocks
 *  -   see clock manager component for details
 */
CLOCK_SYS_Init(g_clockManConfigsArr, CLOCK_MANAGER_CONFIG_CNT,
			   g_clockManCallbacksArr, CLOCK_MANAGER_CALLBACK_CNT);
CLOCK_SYS_UpdateConfiguration(0U, CLOCK_MANAGER_POLICY_AGREEMENT);

/* Initialize pins
 *  -   See PinSettings component for more info
 */
PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr);

/* Initialize FTM PWM channel 0 PTD15
 *  -   See ftm component for more info
 */
FTM_DRV_Init(INST_FLEXTIMER_PWM1, &flexTimer_pwm1_InitConfig, &ftmStateStruct);
/* Initialize FTM PWM channel */
FTM_DRV_InitPwm(INST_FLEXTIMER_PWM1, &flexTimer_pwm1_PwmConfig);

  /* For example: for(;;) { } */
/* Infinite loop
    *  -   increment or decrement duty cycle
    *  -   Update channel duty cycle
    *  -   Wait for a number of cycles to make
    *      the change visible
    */
	while (1)
	{
		if (increaseDutyCycle == false)
		   {
		       if (dutyCycle > 1U)
		           dutyCycle--;
		       else
		           increaseDutyCycle = true;
		   }
		   else
		   {
		       if (dutyCycle < PWM_MAX)
		           dutyCycle++;
		       else
		           increaseDutyCycle = false;
		   }

		   FTM_DRV_UpdatePwmChannel(INST_FLEXTIMER_PWM1,
		                            0U,
		                            FTM_PWM_UPDATE_IN_DUTY_CYCLE,
		                            dutyCycle,
		                            0U,
		                            true);

		   delayCycles(0x2FFU);
	}
  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;) {
    if(exit_code != 0) {
      break;
    }
  }
  return exit_code;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.1 [05.21]
**     for the NXP S32K series of microcontrollers.
**
** ###################################################################
*/
