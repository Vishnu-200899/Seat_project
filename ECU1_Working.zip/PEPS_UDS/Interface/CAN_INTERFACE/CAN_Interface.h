#ifndef CAN_INTERFACE_H_
#define CAN_INTERFACE_H_

#include <stdint.h>
#include "canCom1.h"
#include "pins_driver.h"
#include "flexcan_driver.h"

/* ================= ECU IDs ================= */
#define AG_ECU1_ID        (0x123U)
#define AG_ECU_ID         (0x124U)

/* ================= CAN Configuration ================= */
#define TX_MSG_ID         (AG_ECU_ID)        // 0x123
#define RX_MSG_ID_BCM     (AG_ECU1_ID)       // 0x123

/* ================= Mailbox Assignment ================= */
#define TX_MAILBOX        (1UL)
#define RX_MAILBOX_BCM    (2UL)

/* ================= GPIO / LED Port Definition ================= */
#define LED_PORT          PORTD
#define GPIO_PORT         PTD
#define PCC_INDEX         PCC_PORTD_INDEX
#define LED0              (15U)
#define LED1              (16U)
#define LED2              (0U)

/* ================= LED Pin Assignments ================= */
#define FAN_LED_PORT      PTD
#define FAN_LED_PIN       (0U)               // PTD0
#define HEATER1_LED_PORT  PTD
#define HEATER1_LED_PIN   (1U)               // PTD1
#define HEATER2_LED_PORT  PTD
#define HEATER2_LED_PIN   (2U)               // PTD2
#define HEATER3_LED_PORT  PTD
#define HEATER3_LED_PIN   (3U)               // PTD3

/* ================= CAN Frame Size ================= */
#define CAN_FRAME_SIZE    (8U)

/* ================= Data Structures ================= */
typedef struct
{
    uint8_t state;
    uint8_t data[CAN_FRAME_SIZE];
    uint32_t Tx_MSG_ID;
    uint32_t Tx_Mailbox;
} Can_Tx;

typedef struct
{
    uint8_t data[CAN_FRAME_SIZE];
    uint8_t FLAG;
    uint32_t Rx_MSG_ID;
    uint32_t Rx_Mailbox;
} Can_Rx;

/* ================= External FlexCAN State ================= */
extern flexcan_state_t canCom1_State;

/* ================= Function Prototypes ================= */
void Can_Interface(void);
void CAN_receive(const flexcan_msgbuff_t *rxMsg);
void FlexCANInit(void);
void SendCANData(uint32_t mailbox, uint32_t messageId, uint8_t *Local_Buff, uint32_t len);
void flexcan0_Callback(uint8_t instance, flexcan_event_type_t eventType, uint32_t buffIdx, flexcan_state_t *flexcanState);
void flexcan0_ErrorCallback(uint8_t instance, flexcan_event_type_t eventType, flexcan_state_t *flexcanState);

#endif /* CAN_INTERFACE_H_ */
