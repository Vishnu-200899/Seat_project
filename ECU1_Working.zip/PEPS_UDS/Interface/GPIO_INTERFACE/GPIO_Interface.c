#include "GPIO_Interface.h"
#include "clockMan1.h"
#include "CAN_Interface.h"

void BoardInit(void)
{
    CLOCK_SYS_Init(g_clockManConfigsArr, CLOCK_MANAGER_CONFIG_CNT,
                        g_clockManCallbacksArr, CLOCK_MANAGER_CALLBACK_CNT);
    CLOCK_SYS_UpdateConfiguration(0U, CLOCK_MANAGER_POLICY_FORCIBLE);

    PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr);
}

void GPIOInit(void)
{
    status_t status;

    /* Configure main LEDs */
    PINS_DRV_SetPinsDirection(GPIO_PORT,
                              (1UL << LED0) |
                              (1UL << LED1) |
                              (1UL << LED2));

    /* Configure FAN + Heater LEDs */
    PINS_DRV_SetPinsDirection(FAN_LED_PORT,
                              (1UL << FAN_LED_PIN) |
                              (1UL << HEATER1_LED_PIN) |
                              (1UL << HEATER2_LED_PIN) |
                              (1UL << HEATER3_LED_PIN));

    /* Turn OFF all LEDs */
    PINS_DRV_WritePin(FAN_LED_PORT, FAN_LED_PIN, 0U);
    PINS_DRV_WritePin(HEATER1_LED_PORT, HEATER1_LED_PIN, 0U);
    PINS_DRV_WritePin(HEATER2_LED_PORT, HEATER2_LED_PIN, 0U);
    PINS_DRV_WritePin(HEATER3_LED_PORT, HEATER3_LED_PIN, 0U);

    /* LPIT Initialization */
    LPIT_DRV_Init(INST_LPIT_CONFIG_1, &lpit1_InitConfig);

    status = LPIT_DRV_InitChannel(INST_LPIT_CONFIG_1,
                                  LPIT_CHANNEL,
                                  &lpit1_ChnConfig0);

    DEV_ASSERT(status == STATUS_SUCCESS);

    INT_SYS_InstallHandler(LPIT_Channel_IRQn, &LPIT_ISR, NULL);

    LPIT_DRV_StartTimerChannels(INST_LPIT_CONFIG_1,
                                (1UL << LPIT_CHANNEL));
}
