#include"Timer_Gen.h"
#include"lpTmr1.h"
#include <interrupt_manager.h>
#include <stdint.h>
#include <stdbool.h>

volatile unsigned int mSec_Counter=0,Sec_Cnt=0,mSec1_Counter=0,mSec2_Counter=0, mSec3_Counter=0,Sec1_Counter=0;
volatile unsigned char mSec1Flag=false,mSec2Flag=false,mSec3Flag=false,Sec1_Flag=false;

void Timer_Init(void)
{
    LPTMR_DRV_Init(INST_LPTMR1, &lpTmr1_config0, false);
    INT_SYS_EnableIRQ(LPTMR0_IRQn);
    LPTMR_DRV_StartCounter(INST_LPTMR1);
}

void LPTMR0_IRQHandler(void)
{
    LPTMR_DRV_ClearCompareFlag(INST_LPTMR1);

    mSec_Counter++;
    if(mSec_Counter==1000)
     {
    	mSec_Counter=0;
    	Sec_Cnt++;
     }
    if(Sec_Cnt>=60)
     {
    	Sec_Cnt=0;
     }

    if(mSec1_Counter==mSec_Counter)
     {
        mSec1Flag=true;
        mSec1_Counter=10000;
     }
	if(mSec2_Counter==mSec_Counter)
	 {
		mSec2Flag=true;
		mSec2_Counter=10000;
	 }

	if(Sec1_Counter==Sec_Cnt)
	 {
		Sec1_Flag = true;
		Sec1_Counter=65;
	 }
}

void mSec_timer1(unsigned int mSecTime)
{
	unsigned int Cnt=1000;
	mSec1_Counter=mSec_Counter+mSecTime;
	if(mSec1_Counter >= Cnt)
	 {
		mSec1_Counter=mSec1_Counter-1000;
	 }
}

void mSec_timer2(unsigned int mSecTime)
{
	unsigned int Cnt=1000;
	mSec2_Counter=mSec_Counter+mSecTime;
	if(mSec2_Counter >= Cnt)
	 {
		mSec2_Counter=mSec2_Counter-1000;
	 }
}

void Sec1_Timer(unsigned int SecTime)
{
	unsigned int Cnt=60;
	mSec_Counter=0;
	Sec1_Counter=Sec_Cnt+SecTime;
	if(Sec1_Counter >= Cnt)
	 {
		Sec1_Counter=Sec1_Counter-60;
	 }
}
