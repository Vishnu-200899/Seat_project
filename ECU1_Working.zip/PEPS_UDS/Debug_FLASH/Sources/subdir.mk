################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Sources/Scheduler.c \
../Sources/TIMER_GEN.c \
../Sources/main.c 

OBJS += \
./Sources/Scheduler.o \
./Sources/TIMER_GEN.o \
./Sources/main.o 

C_DEPS += \
./Sources/Scheduler.d \
./Sources/TIMER_GEN.d \
./Sources/main.d 


# Each subdirectory must supply rules for building sources it contributes
Sources/%.o: ../Sources/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@Sources/Scheduler.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


