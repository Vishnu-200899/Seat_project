#ifndef SCHEDULER_H_
#define SCHEDULER_H_

void Task_5ms();
void Task_10ms();
void Task_100ms();
void Task_5000ms();
void Task_1s();

#endif /* SCHEDULER_H_ */
