#ifndef TIMER_GEN_H_
#define TIMER_GEN_H_

void Timer_Init(void);
void mSec_timer1(unsigned int mSecTime);
void mSec_timer2(unsigned int mSecTime);
void Sec1_Timer(unsigned int SecTime);

#endif /* TIMER_GEN_H_ */
