#ifndef GPIO_INTERFACE_H_
#define GPIO_INTERFACE_H_

#define LPIT_CHANNEL        0UL
#define LPIT_Channel_IRQn   LPIT0_Ch0_IRQn
#define INST_LPIT_CONFIG_1  (0U)

void BoardInit(void);
void GPIOInit(void);
void LPIT_ISR(void);
void buttonISR(void);

#endif /* GPIO_INTERFACE_H_ */
