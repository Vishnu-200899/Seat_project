################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Interface/CAN_INTERFACE/CAN_Interface.c 

OBJS += \
./Interface/CAN_INTERFACE/CAN_Interface.o 

C_DEPS += \
./Interface/CAN_INTERFACE/CAN_Interface.d 


# Each subdirectory must supply rules for building sources it contributes
Interface/CAN_INTERFACE/%.o: ../Interface/CAN_INTERFACE/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@Interface/CAN_INTERFACE/CAN_Interface.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


