################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Interface/GPIO_INTERFACE/GPIO_Interface.c 

OBJS += \
./Interface/GPIO_INTERFACE/GPIO_Interface.o 

C_DEPS += \
./Interface/GPIO_INTERFACE/GPIO_Interface.d 


# Each subdirectory must supply rules for building sources it contributes
Interface/GPIO_INTERFACE/%.o: ../Interface/GPIO_INTERFACE/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@Interface/GPIO_INTERFACE/GPIO_Interface.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


