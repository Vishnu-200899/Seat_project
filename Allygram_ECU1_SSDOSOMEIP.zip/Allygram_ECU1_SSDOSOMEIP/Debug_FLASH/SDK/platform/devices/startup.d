SDK/platform/devices/startup.o: ../SDK/platform/devices/startup.c \
 ../SDK/platform/devices/startup.h \
 ../SDK/platform/devices/device_registers.h \
 ../SDK/platform/devices/common/s32_core_cm4.h \
 ../SDK/platform/devices/S32K146/include/S32K146.h \
 ../SDK/platform/devices/S32K146/include/S32K146_features.h \
 ../SDK/platform/devices/devassert.h

../SDK/platform/devices/startup.h:

../SDK/platform/devices/device_registers.h:

../SDK/platform/devices/common/s32_core_cm4.h:

../SDK/platform/devices/S32K146/include/S32K146.h:

../SDK/platform/devices/S32K146/include/S32K146_features.h:

../SDK/platform/devices/devassert.h:
