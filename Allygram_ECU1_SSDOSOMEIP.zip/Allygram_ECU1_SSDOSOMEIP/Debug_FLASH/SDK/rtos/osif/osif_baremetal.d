SDK/rtos/osif/osif_baremetal.o: ../SDK/rtos/osif/osif_baremetal.c \
 ../SDK/rtos/osif/osif.h \
 C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/devices/status.h \
 C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/devices/device_registers.h \
 C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/devices/S32K146/include/S32K146.h \
 C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/devices/S32K146/include/S32K146_features.h \
 C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/devices/devassert.h \
 C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/devices/devassert.h \
 C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/drivers/inc/interrupt_manager.h \
 C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/drivers/inc/clock.h \
 c:\users\public\peps_neelesh\nxp_workspaces\ssdosomeip_workspace\allygram_ecu1_ssdosomeip\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h

../SDK/rtos/osif/osif.h:

C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/devices/status.h:

C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/devices/device_registers.h:

C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/devices/S32K146/include/S32K146.h:

C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/devices/S32K146/include/S32K146_features.h:

C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/devices/devassert.h:

C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/devices/devassert.h:

C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/drivers/inc/interrupt_manager.h:

C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/SSDOSOMEIP_Workspace/Allygram_ECU1_SSDOSOMEIP/SDK/platform/drivers/inc/clock.h:

c:\users\public\peps_neelesh\nxp_workspaces\ssdosomeip_workspace\allygram_ecu1_ssdosomeip\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:
