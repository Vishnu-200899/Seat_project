/* main.c - PROCESSOR EXPERT COMPLIANT - S32K146 CAN Node */
#include "Cpu.h"
#include "CAN_Interface.h"
#include "GPIO_Interface.h"
#include "interrupt_manager.h"
#include "timer_Gen.h"
#include "scheduler.h"


/* Task flags - Global for ISR/main loop */

extern volatile uint32_t statusLedTimer;
volatile int exit_code = 0;
uint8_t Task10ms = 0;
extern volatile bool sec10_flag;
extern flexcan_msgbuff_t recvBuff;
/* LPIT ISR - 10ms task trigger */
void LPIT_ISR(void)
{
    if (LPIT_DRV_GetInterruptFlagTimerChannels(INST_LPIT_CONFIG_1, (1 << LPIT_CHANNEL)))
    {
        LPIT_DRV_ClearInterruptFlagTimerChannels(INST_LPIT_CONFIG_1, (1 << LPIT_CHANNEL));
        Task10ms++;  /* Increment 10ms task counter */
    }
}

/*** Processor Expert start of main routine ***/
int main(void)
{
  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  #ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();
  #endif
  /*** End of Processor Expert internal initialization.                    ***/

  /* === SYSTEM INITIALIZATION SEQUENCE === */
  BoardInit();     // Clocks + Pin muxing (Processor Expert generated)
  GPIOInit();      // LEDs OFF + LPIT Channel 0 (10ms)
  Timer_Init();    // LPTMR1 1ms system backup timer
  FlexCANInit();   // CAN RX Mailbox 2 (ID 0x123)

  flexcan_data_info_t dataInfo = { .data_length = 8U, .msg_id_type =
      			FLEXCAN_MSG_ID_STD, .enable_brs = false, .fd_enable = false,
      			.fd_padding = 0U };

  /* Configure RX message buffer with index RX_MSG_ID and RX_MAILBOX */
      	FLEXCAN_DRV_ConfigRxMb(INST_CANCOM1, RX_MAILBOX_ECU1, &dataInfo,
      	RX_MSG_ID_ECU1);

      	/* Start receiving data in RX_MAILBOX. */
      	FLEXCAN_DRV_Receive(INST_CANCOM1, RX_MAILBOX_ECU1, &recvBuff);
  /* === MAIN SCHEDULER LOOP === */
  while (1)
  {

	  if (sec10_flag)
	  {
	       sec10_flag = false;
	       Task_10ms();
	  }
	  /* Status LED timeout - 200ms blink */
	  if(statusLedTimer > 0)
	  {
	      statusLedTimer--;

	      if(statusLedTimer == 0)
	      {
	          PINS_DRV_ClearPins(GPIO_PORT, (1U << LED0));
	      }
	  }

    /* Exit condition */
    if (exit_code != 0)
    {
        break;
    }
  }

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;) {
    if(exit_code != 0) {
      break;
    }
  }
  return exit_code;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
}
/*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/
