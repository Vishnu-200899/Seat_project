/* CAN_Interface.c - 10ms TX ONLY - FINAL VERSION */
#include "CAN_Interface.h"
#include "flexcan_driver.h"
#include <stdio.h>


/* Local RX buffer */
flexcan_msgbuff_t recvBuff;

/* Status LED timer - self-contained */
volatile uint32_t statusLedTimer = 0U;
volatile uint32_t susLedTimer_ms = 0U;
volatile uint32_t lumbarLedTimer_ms = 0U;
#define STATUS_LED_TIMEOUT_TICKS 20U  // ~200ms
uint8_t  prevSecValueC1     = 0U;
uint8_t  currSecValueC1     = 0U;
uint8_t  prevSecValueC2     = 0U;
uint8_t  currSecValueC2     = 0U;


/* TX status message */
Can_Tx s1 = {
    .data = {'H','W','2',':','1',0,0,0},
    .state = 0U,
    .Tx_MSG_ID = TX_MSG_ID,
    .Tx_Mailbox = TX_MAILBOX       // Mailbox 1
};

Can_Rx s2;


void CAN_SendReedSwitch(uint8_t state)
{
    uint8_t txData[8];
    uint8_t len;

    len = (uint8_t)snprintf((char *)txData, sizeof(txData), "O:%u", state);

    if (len > 8U)
    {
        len = 8U;
    }

    SendCANData(1U, 0x789U, txData, len);
}
// ========== CAN SEND FUNCTION ==========
//void CAN_SendReedSwitch(uint8_t state)
//{
//    uint8_t txData[8];
//    uint8_t len;
//
//    // Format: "r:0" for open, "r:1" for closed
//    len = (uint8_t)snprintf((char *)txData, sizeof(txData), "r:%u", state);
//
//    if (len > 8U)
//    {
//        len = 8U;
//    }
//
//    // Pad remaining bytes with zeros
//    for (uint8_t i = len; i < 8U; i++)
//    {
//        txData[i] = 0U;
//    }
//
//    SendCANData(1U, 0x789U, txData, len);
//}
void TransmitValveFeedbackAck(uint8_t valve, uint8_t state)
{
    uint8_t txData[8];
    uint8_t len;

    /* Format: v1:1 or v2:0 */
    len = (uint8_t)snprintf((char *)txData, sizeof(txData), "v%u:%u", valve, state);

    /* Clamp length */
    if (len > 8U)
    {
        len = 8U;
    }

    SendCANData(1U, 0x456U, txData, len);  /* mailbox = 1 */
}

/* ==================== 10ms MAIN FUNCTION ==================== */
void Can_Interface(void) {
    /* TX "HW1:1" EVERY 10ms on ID 0x124 */
    s1.data[7] = s1.state;
    SendCANData(TX_MAILBOX, TX_MSG_ID, s1.data, CAN_FRAME_SIZE);
}

/* ==================== FLEXCAN INIT ==================== */
void FlexCANInit(void) {
    flexcan_data_info_t dataInfo = {
        .data_length = CAN_FRAME_SIZE,
        .msg_id_type = FLEXCAN_MSG_ID_STD,
        .enable_brs  = false,
        .fd_enable   = false,
        .fd_padding  = 0U
    };

    /* Initialize driver */
    FLEXCAN_DRV_Init(INST_CANCOM1, &canCom1_State, &canCom1_InitConfig0);

    /* Install callbacks */
    FLEXCAN_DRV_InstallEventCallback(INST_CANCOM1, (flexcan_callback_t)flexcan0_Callback, NULL);
    FLEXCAN_DRV_InstallErrorCallback(INST_CANCOM1, (flexcan_error_callback_t)flexcan0_ErrorCallback, NULL);

    /* RX Mailbox: ID 0x123 only */
    FLEXCAN_DRV_ConfigRxMb(INST_CANCOM1, RX_MAILBOX_ECU2, &dataInfo, RX_MSG_ID_ECU2);
    FLEXCAN_DRV_Receive(INST_CANCOM1, RX_MAILBOX_ECU2, &recvBuff);
}

void flexcan0_Callback(uint8_t instance, flexcan_event_type_t eventType,
                      uint32_t buffIdx, flexcan_state_t *flexcanState)
{
    (void)instance;           // Suppress warning
    (void)flexcanState;       // Suppress warning

    if(eventType == FLEXCAN_EVENT_RX_COMPLETE && buffIdx == RX_MAILBOX_ECU2) {
        printf("CALLBACK: RX MB=%lu\\r\\n", (unsigned long)buffIdx);
        CAN_receive(&recvBuff);
        FLEXCAN_DRV_Receive(INST_CANCOM1, RX_MAILBOX_ECU2, &recvBuff);
    }
}

/* ==================== ERROR HANDLER ==================== */
void flexcan0_ErrorCallback(uint8_t instance, flexcan_event_type_t eventType,
                           flexcan_state_t *flexcanState)
{
    (void)instance;
    (void)flexcanState;

    if(eventType == FLEXCAN_EVENT_ERROR)
    {
        uint32_t error = FLEXCAN_DRV_GetErrorStatus(INST_CANCOM1);
        if(error & 0x4U)
        {
            // Bus-off
            FLEXCAN_DRV_AbortTransfer(INST_CANCOM1, TX_MAILBOX);
            PINS_DRV_ClearPins(GPIO_PORT, 1 << LED1);
        }
    }
}

/* ==================== SEND FUNCTION ==================== */
void SendCANData(uint32_t mailbox, uint32_t messageId, uint8_t *Local_Buff, uint32_t len)
{
    flexcan_data_info_t dataInfo =
    {
        .data_length = (len > 8) ? 8 : len,
        .msg_id_type = FLEXCAN_MSG_ID_STD,
        .enable_brs  = false,
        .fd_enable   = false,
        .fd_padding  = 0U
    };

    FLEXCAN_DRV_ConfigTxMb(INST_CANCOM1, mailbox, &dataInfo, messageId);
    FLEXCAN_DRV_Send(INST_CANCOM1, mailbox, &dataInfo, messageId, Local_Buff);
}

void CAN_receive(const flexcan_msgbuff_t *rxMsg)
{
    if(rxMsg == NULL)
    {
        return;
    }

    /* Blink status LED */
    PINS_DRV_SetPins(GPIO_PORT, (1U << LED0));
    statusLedTimer = 100000;

    printf("RX ID=0x%03lX DLC=%d : ",
           (unsigned long)rxMsg->msgId,
           rxMsg->dataLen);

    for(uint8_t i=0;i<rxMsg->dataLen;i++)
    {
        printf("%02X ", rxMsg->data[i]);
    }
    printf("\r\n");
    // ========== C1 LED Control ==========
    if (rxMsg->dataLen >= 4 &&
        rxMsg->data[0] == 'C' &&
        rxMsg->data[1] == '1' &&
        rxMsg->data[2] == ':')
    {
        char cmd = rxMsg->data[3];  // Command character '0'-'5'

        // Validate command: '0'-'5' representing seconds
        if (cmd >= '0' && cmd <= '5')
        {
            uint8_t targetSecValue1 = cmd - '0';  // Convert ASCII to numeric value (0-5)

            if (targetSecValue1 > 0)
            {
                // Turn ON LED for target seconds duration
                PINS_DRV_SetPins(SUS_LED_PORT, (1U << SUS_LED_PIN));
                // Set timer for target duration (convert seconds to ms)
                susLedTimer_ms = targetSecValue1 * 1000;

                // Debug message
                printf("C1 LED ON: Will stay ON for %d second(s)\r\n", targetSecValue1);
            }
            else if(targetSecValue1<0)
			{

            	PINS_DRV_ClearPins(SUS_LED_PORT, (1U << SUS_LED_PIN));
            	                // Set timer for target duration (convert seconds to ms)
            	 susLedTimer_ms = 0;


			}
            else  // targetSecValue == 0
            {
                // Turn OFF LED immediately
                PINS_DRV_ClearPins(SUS_LED_PORT, (1U << SUS_LED_PIN));
                susLedTimer_ms = 0;

                // Debug message
                printf("C1 LED OFF: Duration 0 seconds\r\n");
            }

            // Store current value for monitoring
            prevSecValueC1 = targetSecValue1;
        }
    }
    // ========== C2 LED Control ==========
    else if (rxMsg->dataLen >= 4 &&
             rxMsg->data[0] == 'C' &&
             rxMsg->data[1] == '2' &&
             rxMsg->data[2] == ':')
    {
        char cmd = rxMsg->data[3];  // Command character '0'-'5'

        // Validate command: '0'-'5' representing seconds
        if (cmd >= '0' && cmd <= '5')
        {
            uint8_t targetSecValue2 = cmd - '0';  // Convert ASCII to numeric value (0-5)

            if (targetSecValue2 > 0)
            {
                // Turn ON LED for target seconds duration
                PINS_DRV_SetPins(LUMBAR_LED_PORT, (1U << LUMBAR_LED_PIN));
                // Set timer for target duration (convert seconds to ms)
                lumbarLedTimer_ms = targetSecValue2 * 1000;

                // Debug message
                printf("C2 LED ON: Will stay ON for %d second(s)\r\n", targetSecValue2);
            }
            else if(targetSecValue2 < 0)
            {
                PINS_DRV_ClearPins(LUMBAR_LED_PORT, (1U << LUMBAR_LED_PIN));
                lumbarLedTimer_ms = 0;

                // Debug message
                printf("targetSecValue2 < 0: Relay OFF immediately\r\n");
            }
            else  // targetSecValue == 0
            {
                // Turn OFF LED immediately
                PINS_DRV_ClearPins(LUMBAR_LED_PORT, (1U << LUMBAR_LED_PIN));
                lumbarLedTimer_ms = 0;

                // Debug message
                printf("C2 LED OFF: Duration 0 seconds\r\n");
            }

            // Store current value for monitoring
            prevSecValueC2 = targetSecValue2;
        }
    }
    else if (rxMsg->dataLen >= 4U &&
             rxMsg->data[0] == 'V' &&
             rxMsg->data[2] == ':')
    {
        /* Convert '1','2','3' → 0,1,2 */
        uint8_t valveIndex = (uint8_t)(rxMsg->data[1] - '1');

        if (valveIndex < TOTAL_VALVES)
        {
            if (rxMsg->data[3] == '1')
            {
                /* ON with retrigger - reset timer to 5 seconds */
                valveCtrl[valveIndex].state = VALVE_ON;
                valveCtrl[valveIndex].timeout5sec = 1U;
                valveCtrl[valveIndex].timer_ms = 5000;  // 5 seconds (5000 * 1ms)

                Valve_Set(valveIndex, VALVE_ON);
                TransmitValveFeedbackAck(valveIndex + 1U, VALVE_ON);

                // Optional debug
                printf("Valve %d ON, will auto-off in 5 sec\r\n", valveIndex + 1);
            }
            else
            {
                /* OFF - cancel timer immediately */
                valveCtrl[valveIndex].state = VALVE_OFF;
                valveCtrl[valveIndex].timeout5sec = 0U;
                valveCtrl[valveIndex].timer_ms = 0;

                Valve_Set(valveIndex, VALVE_OFF);
                TransmitValveFeedbackAck(valveIndex + 1U, VALVE_OFF);

                // Optional debug
                printf("Valve %d OFF immediately\r\n", valveIndex + 1);
            }
        }
    }
}
