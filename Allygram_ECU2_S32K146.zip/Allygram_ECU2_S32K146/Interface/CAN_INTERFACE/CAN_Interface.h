#ifndef CAN_INTERFACE_H_
#define CAN_INTERFACE_H_

#include <stdint.h>
#include "canCom1.h"
#include "pins_driver.h"
#include "flexcan_driver.h"

/* ================= ECU IDs ================= */
#define AG_ECU2_ID        (0x456U)
#define AG_ECU_ID         (0x456U)

/* ================= CAN Configuration ================= */
#define TX_MSG_ID         (AG_ECU_ID)        // 0x456
#define RX_MSG_ID_ECU2     (AG_ECU2_ID)       // 0x456

/* ================= Mailbox Assignment ================= */
#define TX_MAILBOX        (1UL)
#define RX_MAILBOX_ECU2    (2UL)

/* ================= GPIO / LED Port Definition ================= */
#define LED_PORT          PORTD
#define GPIO_PORT         PTD
#define PCC_INDEX         PCC_PORTD_INDEX
#define LED0              (15U)
#define LED1              (16U)
/* ================= LED Pin Assignments ================= */
#define SUS_LED_PORT      PTD      // PTD1
#define SUS_LED_PIN       (1U)

#define VALVE1_LED_PORT  PTD      // PTD2
#define VALVE1_LED_PIN   (2U)

#define LUMBAR_LED_PORT  PTD      // PTD3
#define LUMBAR_LED_PIN   (3U)

#define VALVE2_LED_PORT  PTD      // PTD4
#define VALVE2_LED_PIN   (4U)

#define VALVE3_LED_PORT  PTD      // PTD5
#define VALVE3_LED_PIN   (5U)



#define DEBOUNCE_MS        50U      // 50ms debounce time

/* ================= CAN Frame Size ================= */
#define CAN_FRAME_SIZE    (8U)

#define TOTAL_VALVES        (3U)

#define VALVE_ON            (1U)
#define VALVE_OFF           (0U)
/* ================= Data Structures ================= */
typedef struct
{
    uint8_t state;
    uint8_t data[CAN_FRAME_SIZE];
    uint32_t Tx_MSG_ID;
    uint32_t Tx_Mailbox;
} Can_Tx;

typedef struct
{
    uint8_t data[CAN_FRAME_SIZE];
    uint8_t FLAG;
    uint32_t Rx_MSG_ID;
    uint32_t Rx_Mailbox;
} Can_Rx;

typedef struct
{
    uint8_t state;
    uint8_t timeout5sec;
    uint32_t timer_ms;
} ValveControl_t;

/* Global variable */
extern ValveControl_t valveCtrl[TOTAL_VALVES];

/* Function */
void Valve_Set(uint8_t index, uint8_t state);
//void CAN_SendReedSwitch(uint8_t state);
/* ================= External FlexCAN State ================= */
extern flexcan_state_t canCom1_State;
//extern volatile uint32_t statusLedTimer;  // Add this line

/* ================= Function Prototypes ================= */
void Can_Interface(void);
void CAN_receive(const flexcan_msgbuff_t *rxMsg);
void FlexCANInit(void);
void SendCANData(uint32_t mailbox, uint32_t messageId, uint8_t *Local_Buff, uint32_t len);
void flexcan0_Callback(uint8_t instance, flexcan_event_type_t eventType, uint32_t buffIdx, flexcan_state_t *flexcanState);
void flexcan0_ErrorCallback(uint8_t instance, flexcan_event_type_t eventType, flexcan_state_t *flexcanState);
void TransmitValveFeedbackAck(uint8_t valve, uint8_t state);
void CAN_SendReedSwitch(uint8_t state);
#endif /* CAN_INTERFACE_H_ */
