#include "GPIO_Interface.h"
#include "clockMan1.h"
#include "CAN_Interface.h"
#include<stdio.h>
#include "pins_driver.h"
#include "pin_mux.h"

void BoardInit(void)
{
    CLOCK_SYS_Init(g_clockManConfigsArr, CLOCK_MANAGER_CONFIG_CNT,
                        g_clockManCallbacksArr, CLOCK_MANAGER_CALLBACK_CNT);
    CLOCK_SYS_UpdateConfiguration(0U, CLOCK_MANAGER_POLICY_FORCIBLE);

    PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr);
}

void GPIOInit(void)
{
    /* Configure all output pins together */
    PINS_DRV_SetPinsDirection(PTD,
        (1UL << LED0) |
        (1UL << LED1) |
        (1UL << SUS_LED_PIN) |
        (1UL << VALVE1_LED_PIN) |
        (1UL << LUMBAR_LED_PIN) |
        (1UL << VALVE2_LED_PIN) |
		(1UL << VALVE3_LED_PIN) |
		(1UL << REEDIN_LED_PIN)
    );

    /* Turn OFF all LEDs */
    PINS_DRV_ClearPins(PTD,
    		(1UL << SUS_LED_PIN) |
    		        (1UL << VALVE1_LED_PIN) |
    		        (1UL << LUMBAR_LED_PIN) |
    		        (1UL << VALVE2_LED_PIN) |
    				(1UL << VALVE3_LED_PIN) |
					(1UL << REEDIN_LED_PIN)
    );
    PINS_DRV_ReadPins(REEDSW_LED_PORT);
   // PINS_DRV_WritePin(REEDIN_LED_PORT,REEDIN_LED_PIN, 1U);
   // PINS_DRV_WritePin(REEDIN_LED_PORT,REEDIN_LED_PIN, 0U);
    /* LPIT Initialization */
    LPIT_DRV_Init(INST_LPIT_CONFIG_1, &lpit1_InitConfig);

    LPIT_DRV_InitChannel(INST_LPIT_CONFIG_1,
                         LPIT_CHANNEL,
                         &lpit1_ChnConfig0);

    INT_SYS_InstallHandler(LPIT_Channel_IRQn, &LPIT_ISR, NULL);

    LPIT_DRV_StartTimerChannels(INST_LPIT_CONFIG_1,
                                (1UL << LPIT_CHANNEL));
}

void Valve_Set(uint8_t index, uint8_t state)
{
    switch (index)
    {
        case 0: /* V1 */
            if (state == VALVE_ON)
            {
                PINS_DRV_SetPins(VALVE1_LED_PORT, (1UL << VALVE1_LED_PIN));
            }
            else
            {
                PINS_DRV_ClearPins(VALVE1_LED_PORT, (1UL << VALVE1_LED_PIN));
            }
            break;

        case 1: /* V2 */
            if (state == VALVE_ON)
            {
                PINS_DRV_SetPins(VALVE2_LED_PORT, (1UL << VALVE2_LED_PIN));
            }
            else
            {
                PINS_DRV_ClearPins(VALVE2_LED_PORT, (1UL << VALVE2_LED_PIN));
            }
            break;

        case 2: /* V3 */
            if (state == VALVE_ON)
            {
                PINS_DRV_SetPins(VALVE3_LED_PORT, (1UL << VALVE3_LED_PIN));
            }
            else
            {
                PINS_DRV_ClearPins(VALVE3_LED_PORT, (1UL << VALVE3_LED_PIN));
            }
            break;

        default:
            /* Safety */
            break;
    }
}

//void ReedSwitch_Task_Simple(void)
//{
//    uint32_t portValue;
//
//    // Read reed switch (equivalent to HAL_GPIO_ReadPin)
//    portValue = PINS_DRV_ReadPins(REEDSW_LED_PORT);
//
//    // Check if reed switch is activated (active low = 0 when magnet present)
//    if ((portValue & (1UL << REEDSW_LED_PIN)) == 0U)  // GPIO_PIN_RESET
//    {
//        // Turn on LED (equivalent to HAL_GPIO_WritePin with GPIO_PIN_SET)
//        PINS_DRV_SetPins(REEDIN_LED_PORT, (1UL << REEDIN_LED_PIN));
//        ledOn = 1U;
//    }
//    else
//    {
//        // Turn off LED (equivalent to HAL_GPIO_WritePin with GPIO_PIN_RESET)
//        PINS_DRV_ClearPins(REEDIN_LED_PORT, (1UL << REEDIN_LED_PIN));
//        ledOn = 0U;
//    }
//
//    // Send CAN message only when state changes
//    if (ledOn != prevLedOn)
//    {
//        CAN_SendReedSwitch(ledOn);  // Your existing CAN send function
//        prevLedOn = ledOn;
//    }
//}
//void ReedSwitch_Init(void)
//{
//    // Configure PTD6 as input with pull-up
//    // Cast PTD (GPIO_Type*) to PORT_Type* for PORT functions
//    PINS_DRV_SetMuxModeSel((PORT_Type *)REEDSW_LED_PORT, REEDSW_LED_PIN, PORT_MUX_AS_GPIO);
//    PINS_DRV_SetPullSel((PORT_Type *)REEDSW_LED_PORT, REEDSW_LED_PIN, PORT_INTERNAL_PULL_UP_ENABLED);
//    PINS_DRV_SetPinDirection(REEDSW_LED_PORT, REEDSW_LED_PIN, GPIO_INPUT_DIRECTION);
//
//    // Configure PTD7 as output for LED
//    PINS_DRV_SetMuxModeSel((PORT_Type *)REEDIN_LED_PORT, REEDIN_LED_PIN, PORT_MUX_AS_GPIO);
//    PINS_DRV_SetPinDirection(REEDIN_LED_PORT, REEDIN_LED_PIN, GPIO_OUTPUT_DIRECTION);
//    PINS_DRV_ClearPins(REEDIN_LED_PORT, (1UL << REEDIN_LED_PIN));
//
//    printf("Reed switch initialized\r\n");
//}
//
//void ReedSwitch_Task_Simple(void)
//{
//    static uint8_t prevState = 0U;
//    uint8_t currentState;
//    uint32_t portValue;
//
//    // Read reed switch
//    portValue = PINS_DRV_ReadPins(REEDSW_LED_PORT);
//    currentState = ((portValue & (1UL << REEDSW_LED_PIN)) == 0U) ? 1U : 0U;
//
//    // Update LED output
//    if (currentState == 1U)
//    {
//        PINS_DRV_SetPins(REEDIN_LED_PORT, (1UL << REEDIN_LED_PIN));
//    }
//    else
//    {
//        PINS_DRV_ClearPins(REEDIN_LED_PORT, (1UL << REEDIN_LED_PIN));
//    }
//
//    // Send CAN message only when state changes
//    if (currentState != prevState)
//    {
//        CAN_SendReedSwitch(currentState);
//        printf("Reed switch state changed to: %u\r\n", currentState);
//        prevState = currentState;
//    }
//}
