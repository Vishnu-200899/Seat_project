#ifndef GPIO_INTERFACE_H_
#define GPIO_INTERFACE_H_
#include <stdint.h>
#include "pins_driver.h"

#define LPIT_CHANNEL        0UL
#define LPIT_Channel_IRQn   LPIT0_Ch0_IRQn
#define INST_LPIT_CONFIG_1  (0U)

#define REEDSW_LED_PORT  PTD      // PTD6 input
#define REEDSW_LED_PIN   (6U)

#define REEDIN_LED_PORT  PTD      // PTD7 output
#define REEDIN_LED_PIN   (7U)

void BoardInit(void);
void GPIOInit(void);
void LPIT_ISR(void);
void buttonISR(void);
//void ReedSwitch_Init(void);
void ReedSwitch_Task_Simple(void);
#endif /* GPIO_INTERFACE_H_ */
