#include"Scheduler.h"
#include "GPIO_Interface.h"
#include "interrupt_manager.h"
#include "CAN_Interface.h"

volatile uint8_t sec5_flag = 0U;
void Task_10ms()
{
   Can_Interface();  // TX 0x123 "HW1:1" every 10ms
}

