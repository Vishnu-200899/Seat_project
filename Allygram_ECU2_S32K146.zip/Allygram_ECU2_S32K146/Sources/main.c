/* main.c - PROCESSOR EXPERT COMPLIANT - S32K146 CAN Node */
#include "Cpu.h"
#include "CAN_Interface.h"
#include "GPIO_Interface.h"
#include "interrupt_manager.h"
#include "timer_Gen.h"
#include "scheduler.h"
#include <stdio.h>

/* Task flags - Global for ISR/main loop */

extern volatile uint32_t statusLedTimer;
extern volatile uint32_t susLedTimer_ms;
extern volatile uint32_t lumbarLedTimer_ms;

#define RELAY_DELAY_V1    100  /* Example value in milliseconds */
#define RELAY_DELAY_V2    100
#define RELAY_DELAY_V3    100
#define DEBOUNCE_DELAY_MS 50   /* Example value in milliseconds */
volatile int exit_code = 0;
uint8_t Task10ms = 0;
uint8_t ledOn = 0U;
uint8_t prevLedOn=0U;
extern volatile bool sec10_flag;
extern flexcan_msgbuff_t recvBuff;

ValveControl_t valveCtrl[TOTAL_VALVES] = {
    {VALVE_OFF, 0U, 0},  // Valve 1
    {VALVE_OFF, 0U, 0},  // Valve 2
    {VALVE_OFF, 0U, 0}   // Valve 3
};
extern volatile uint8_t sec5_flag;

/* Function Prototypes */

/* LPIT ISR - 10ms task trigger */
void LPIT_ISR(void)
{
    if (LPIT_DRV_GetInterruptFlagTimerChannels(INST_LPIT_CONFIG_1, (1 << LPIT_CHANNEL)))
    {
        LPIT_DRV_ClearInterruptFlagTimerChannels(INST_LPIT_CONFIG_1, (1 << LPIT_CHANNEL));
        Task10ms++;  /* Increment 10ms task counter */
    }
}


/* ================= Application Functions ================= */


/*** Processor Expert start of main routine ***/
int main(void)
{
  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  #ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();
  #endif
  /*** End of Processor Expert internal initialization.                    ***/

  /* === SYSTEM INITIALIZATION SEQUENCE === */
  BoardInit();     // Clocks + Pin muxing (Processor Expert generated)
  GPIOInit();      // LEDs OFF + LPIT Channel 0 (10ms)
  Timer_Init();    // LPTMR1 1ms system backup timer
  FlexCANInit();   // CAN RX Mailbox 2 (ID 0x456)

  flexcan_data_info_t dataInfo = { .data_length = 8U, .msg_id_type =
      			FLEXCAN_MSG_ID_STD, .enable_brs = false, .fd_enable = false,
      			.fd_padding = 0U };

  /* Configure RX message buffer with index RX_MSG_ID and RX_MAILBOX */
      	FLEXCAN_DRV_ConfigRxMb(INST_CANCOM1, RX_MAILBOX_ECU2, &dataInfo,
      	RX_MSG_ID_ECU2);

      	/* Start receiving data in RX_MAILBOX. */
      	FLEXCAN_DRV_Receive(INST_CANCOM1, RX_MAILBOX_ECU2, &recvBuff);
  /* === MAIN SCHEDULER LOOP === */

  while (1)
  {

	  if (sec10_flag)
	  {
	       sec10_flag = false;
	       Task_10ms();
	  }
	  /* Status LED timeout - 200ms blink */
	  if(statusLedTimer > 0)
	  {
	      statusLedTimer--;

	      if(statusLedTimer == 0)
	      {
	          PINS_DRV_ClearPins(GPIO_PORT, (1U << LED0));
	      }
	  }

	  if (sec5_flag == 1U)
	  {
		  sec5_flag = 0U;
		  Valve_Task_5sec();  // Called every 1ms
	  }
	  uint32_t portValue;

	      // Read reed switch (equivalent to HAL_GPIO_ReadPin)
	      portValue = PINS_DRV_ReadPins(REEDSW_LED_PORT);

	      // Check if reed switch is activated (active low = 0 when magnet present)
	      if ((portValue & (1UL << REEDSW_LED_PIN)) == 0U)  // GPIO_PIN_RESET
	      {
	          // Turn on LED (equivalent to HAL_GPIO_WritePin with GPIO_PIN_SET)
	    	  PINS_DRV_SetPins(REEDIN_LED_PORT, (1U << REEDIN_LED_PIN));
	          ledOn = 1U;
	      }
	      else
	      {
	          // Turn off LED (equivalent to HAL_GPIO_WritePin with GPIO_PIN_RESET)
	    	  PINS_DRV_ClearPins(REEDIN_LED_PORT,(1U << REEDIN_LED_PIN));
	          ledOn = 0U;
	      }

	      // Send CAN message only when state changes
	      if (ledOn != prevLedOn)
	      {
	          CAN_SendReedSwitch(ledOn);  // Your existing CAN send function
	          prevLedOn = ledOn;
	      }
    /* Exit condition */
    if (exit_code != 0)
    {
        break;
    }
  }

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;) {
    if(exit_code != 0) {
      break;
    }
  }
  return exit_code;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
}
/*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/
