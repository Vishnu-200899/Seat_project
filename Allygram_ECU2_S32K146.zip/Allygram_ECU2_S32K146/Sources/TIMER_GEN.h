#ifndef TIMER_GEN_H_
#define TIMER_GEN_H_

void Timer_Init(void);
void mSec_timer1(unsigned int mSecTime);
void mSec_timer2(unsigned int mSecTime);
void Sec1_Timer(unsigned int SecTime);
void Valve_Task_5sec(void);
void check_sus_led_timer_ms(void);
void check_lumbar_led_timer_ms(void);
void ReedSwitch_Task(void);
#endif /* TIMER_GEN_H_ */
