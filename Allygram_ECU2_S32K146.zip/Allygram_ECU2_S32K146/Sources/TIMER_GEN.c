#include"Timer_Gen.h"
#include"lpTmr1.h"
#include <interrupt_manager.h>
#include <stdint.h>
#include <stdbool.h>
#include "CAN_Interface.h"
#include<stdio.h>
volatile unsigned int mSec_Counter=0,Sec_Cnt=0,mSec1_Counter=0,mSec2_Counter=0, mSec3_Counter=0,Sec1_Counter=0;
volatile unsigned char mSec1Flag=false,mSec2Flag=false,mSec3Flag=false,Sec1_Flag=false;
volatile uint16_t sec10_counter = 0;
volatile bool sec10_flag = false;
extern volatile uint32_t statusLedTimer;
extern volatile uint32_t susLedTimer_ms;
extern volatile uint32_t lumbarLedTimer_ms;
extern volatile uint8_t sec5_flag;
volatile uint32_t systemTimeMs = 0U;
void Timer_Init(void)
{
    LPTMR_DRV_Init(INST_LPTMR1, &lpTmr1_config0, false);
    INT_SYS_EnableIRQ(LPTMR0_IRQn);
    LPTMR_DRV_StartCounter(INST_LPTMR1);
}


void LPTMR0_IRQHandler(void)
{
    LPTMR_DRV_ClearCompareFlag(INST_LPTMR1);
    systemTimeMs++;
    mSec_Counter++;

    /* ✅ Set sec5_flag EVERY 1ms for valve timer */
    sec5_flag = 1U;

    /* ✅ Handle status LED timeout with 1ms precision */
    if(statusLedTimer > 0)
    {
        statusLedTimer--;
        if(statusLedTimer == 0)
        {
            PINS_DRV_ClearPins(GPIO_PORT, (1U << LED0));
        }
    }

    /* ✅ Handle SUS LED timer with 1ms precision */
    // Handle C1 LED timer (SUS LED)
        if (susLedTimer_ms > 0)
        {
            susLedTimer_ms--;
            if (susLedTimer_ms == 0)
            {
                PINS_DRV_ClearPins(SUS_LED_PORT, (1U << SUS_LED_PIN));
                printf("C1 LED auto-off after timer expired\r\n");
            }
        }

    /* ✅ Handle LUMBAR LED timer with 1ms precision */
        if (lumbarLedTimer_ms > 0)
            {
                lumbarLedTimer_ms--;
                if (lumbarLedTimer_ms == 0)
                {
                    PINS_DRV_ClearPins(LUMBAR_LED_PORT, (1U << LUMBAR_LED_PIN));
                    printf("C2 LED auto-off after timer expired\r\n");
                }
            }

    /* Handle 1-second counter */
    if (mSec_Counter >= 1000)
    {
        mSec_Counter = 0;
        Sec_Cnt++;

        sec10_counter++;
        if (sec10_counter >= 10)   // 10 seconds
        {
            sec10_counter = 0;
            sec10_flag = true;
        }

        if (Sec_Cnt >= 60)
        {
            Sec_Cnt = 0;
        }
    }
}

void mSec_timer1(unsigned int mSecTime)
{
	unsigned int Cnt=1000;
	mSec1_Counter=mSec_Counter+mSecTime;
	if(mSec1_Counter >= Cnt)
	 {
		mSec1_Counter=mSec1_Counter-1000;
	 }
}

void mSec_timer2(unsigned int mSecTime)
{
	unsigned int Cnt=1000;
	mSec2_Counter=mSec_Counter+mSecTime;
	if(mSec2_Counter >= Cnt)
	 {
		mSec2_Counter=mSec2_Counter-1000;
	 }
}

void Sec1_Timer(unsigned int SecTime)
{
	unsigned int Cnt=60;
	mSec_Counter=0;
	Sec1_Counter=Sec_Cnt+SecTime;
	if(Sec1_Counter >= Cnt)
	 {
		Sec1_Counter=Sec1_Counter-60;
	 }
}

uint32_t getCurrentTimeMs(void)
{
    return systemTimeMs;
}

void Valve_Task_5sec(void)
{
    for (uint8_t i = 0; i < TOTAL_VALVES; i++)
    {
        if (valveCtrl[i].timeout5sec && valveCtrl[i].timer_ms > 0)
        {
            valveCtrl[i].timer_ms--;  // Decrement timer (1ms per call)

            if (valveCtrl[i].timer_ms == 0)
            {
                // Timer expired - turn off valve
                valveCtrl[i].state = VALVE_OFF;
                valveCtrl[i].timeout5sec = 0U;

                Valve_Set(i, VALVE_OFF);
                TransmitValveFeedbackAck(i + 1U, VALVE_OFF);
            }
        }
    }
}
