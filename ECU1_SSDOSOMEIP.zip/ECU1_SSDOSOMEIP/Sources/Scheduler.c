#include"Scheduler.h"
#include "GPIO_Interface.h"
#include "interrupt_manager.h"
#include "CAN_Interface.h"
uint32_t HW_status=1;
void Task_10ms()
{
	TransmitHardwareStatusAck(HW_status);
   //Can_Interface();  // TX 0x123 "HW1:1" every 10ms
}
