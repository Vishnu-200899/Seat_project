################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Interface/CAN_INTERFACE_TP/CAN_Interface_TP.c 

OBJS += \
./Interface/CAN_INTERFACE_TP/CAN_Interface_TP.o 

C_DEPS += \
./Interface/CAN_INTERFACE_TP/CAN_Interface_TP.d 


# Each subdirectory must supply rules for building sources it contributes
Interface/CAN_INTERFACE_TP/%.o: ../Interface/CAN_INTERFACE_TP/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@Interface/CAN_INTERFACE_TP/CAN_Interface_TP.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


