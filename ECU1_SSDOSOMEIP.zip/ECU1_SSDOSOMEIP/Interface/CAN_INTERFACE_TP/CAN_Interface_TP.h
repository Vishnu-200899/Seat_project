#ifndef CAN_INTERFACE_TP_H_
#define CAN_INTERFACE_TP_H_

#include <stdint.h>
#include "canCom2.h"
#include "pins_driver.h"
#include "flexcan_driver.h"

/* ================= ECU IDs ================= */
#define AG_ECU1_IDTP        (0x143U)
#define AG_ECU_IDTP         (0x341U)

/* ================= CAN Configuration ================= */
#define TX_MSG_IDTP         (AG_ECU_IDTP)        // 0x143
#define RX_MSG_ID_ECU1TP    (AG_ECU1_IDTP)       // 0x341

/* ================= Mailbox Assignment ================= */
#define TX_MAILBOXTP        (1UL)
#define RX_MAILBOX_ECU1TP   (2UL)

/* ================= GPIO / LED Port Definition ================= */
#define LED_PORT          PORTD
#define GPIO_PORT         PTD
#define PCC_INDEX         PCC_PORTD_INDEX
#define LED0              (15U)
#define LED1              (16U)

///* ================= LED Pin Assignments ================= */
//#define FAN_LED_PORT      PTD
//#define FAN_LED_PIN       (4U)
//
//#define HEATER1_LED_PORT  PTD
//#define HEATER1_LED_PIN   (1U)
//
//#define HEATER2_LED_PORT  PTD
//#define HEATER2_LED_PIN   (2U)
//
//#define HEATER3_LED_PORT  PTD
//#define HEATER3_LED_PIN   (3U)

/* ================= CAN Frame Size ================= */
#define CAN_FRAME_SIZETP    (8U)

/* ================= Timing ================= */
#define STATUS_LED_TIMEOUT_TICKSTP  (100000U)  // LED timeout in ticks
#define TX_PERIOD_TICKSTP           (1000U)    // 10ms at 100kHz tick rate (adjust as needed)

/* ================= Data Structures ================= */
typedef struct
{
    uint8_t state;
    uint8_t data[CAN_FRAME_SIZETP];
    uint32_t Tx_MSG_IDTP;
    uint32_t Tx_MailboxTP;
} Can_TxTP;

typedef struct
{
    uint8_t data[CAN_FRAME_SIZETP];
    uint8_t FLAGTP;
    uint32_t Rx_MSG_IDTP;
    uint32_t Rx_MailboxTP;
} Can_RxTP;

/* ================= External FlexCAN State ================= */
extern flexcan_state_t canCom2_State;

/* ================= Function Prototypes ================= */
void Can_InterfaceTP(void);
void CAN_receiveTP(const flexcan_msgbuff_t *rxMsg);
void FlexCANInitTP(void);
void SendCANDataTP(uint32_t mailbox, uint32_t messageId, uint8_t *Local_Buff, uint32_t len);
void flexcan0_CallbackTP(uint8_t instance, flexcan_event_type_t eventType, uint32_t buffIdx, flexcan_state_t *flexcanState);
void flexcan0_ErrorCallbackTP(uint8_t instance, flexcan_event_type_t eventType, flexcan_state_t *flexcanState);
void TransmitHardwareStatusAckTP(uint32_t HW_status);
void UpdateStatusLEDTP(void);

#endif /* CAN_INTERFACE_TP_H_ */
