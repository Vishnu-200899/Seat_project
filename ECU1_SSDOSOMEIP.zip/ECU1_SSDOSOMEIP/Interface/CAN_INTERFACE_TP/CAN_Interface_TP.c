#include "CAN_Interface_TP.h"
#include "flexcan_driver.h"
#include <stdio.h>
#include <string.h>

/* Local RX buffer */
flexcan_msgbuff_t recvBuffTP;

/* Status LED timer - self-contained */
//volatile uint32_t statusLedTimerTP = 0U;
//
///* TX status message */
//Can_Tx s1 = {
//    .data = {'H','W','1',':','1',0,0,0},
//    .state = 0U,
//    .Tx_MSG_ID = TX_MSG_ID,        // 0x124
//    .Tx_Mailbox = TX_MAILBOX       // Mailbox 1
//};

/* ==================== 10ms MAIN FUNCTION ==================== */
//void Can_InterfaceTP(void)
//{
//    /* Update status LED */
//    UpdateStatusLEDTP();
//
//    /* TX "HW1:1" EVERY 10ms on ID 0x124 */
//    s1.data[7] = s1.state;
//    SendCANDataTP(TX_MAILBOX, TX_MSG_ID, s1.data, CAN_FRAME_SIZE);
//}

/* ==================== FLEXCAN INIT ==================== */
void FlexCANInitTP(void)
{
    flexcan_data_info_t dataInfo = {
        .data_length = CAN_FRAME_SIZETP,
        .msg_id_type = FLEXCAN_MSG_ID_STD,
        .enable_brs  = false,
        .fd_enable   = false,
        .fd_padding  = 0U
    };

    /* Initialize driver - using INST_CANCOM2 */
    FLEXCAN_DRV_Init(INST_CANCOM2, &canCom2_State, &canCom2_InitConfig0);

    /* Install callbacks */
    FLEXCAN_DRV_InstallEventCallback(INST_CANCOM2, (flexcan_callback_t)flexcan0_CallbackTP, NULL);
    FLEXCAN_DRV_InstallErrorCallback(INST_CANCOM2, (flexcan_error_callback_t)flexcan0_ErrorCallbackTP, NULL);

    /* RX Mailbox: ID 0x123 only */
    FLEXCAN_DRV_ConfigRxMb(INST_CANCOM2, RX_MAILBOX_ECU1TP, &dataInfo, RX_MSG_ID_ECU1TP);
    FLEXCAN_DRV_Receive(INST_CANCOM2, RX_MAILBOX_ECU1TP, &recvBuffTP);
}

/* ==================== CAN CALLBACK ==================== */
void flexcan0_CallbackTP(uint8_t instance, flexcan_event_type_t eventType,
                      uint32_t buffIdx, flexcan_state_t *flexcanState)
{
    (void)instance;           // Suppress warning
    (void)flexcanState;       // Suppress warning

    if(eventType == FLEXCAN_EVENT_RX_COMPLETE && buffIdx == RX_MAILBOX_ECU1TP)
    {
        printf("CALLBACK: RX MB=%lu\r\n", (unsigned long)buffIdx);
        CAN_receiveTP(&recvBuffTP);
        FLEXCAN_DRV_Receive(INST_CANCOM2, RX_MAILBOX_ECU1TP, &recvBuffTP);
    }
}

/* ==================== ERROR HANDLER ==================== */
void flexcan0_ErrorCallbackTP(uint8_t instance, flexcan_event_type_t eventType,
                           flexcan_state_t *flexcanState)
{
    (void)instance;
    (void)flexcanState;

    if(eventType == FLEXCAN_EVENT_ERROR)
    {
        uint32_t error = FLEXCAN_DRV_GetErrorStatus(INST_CANCOM2);
        if(error & 0x4U)  // Bus-off error
        {
            // Clear LED to indicate error
            PINS_DRV_ClearPins(GPIO_PORT, (1U << LED1));

            // Optionally, abort any pending transfers
            FLEXCAN_DRV_AbortTransfer(INST_CANCOM2, TX_MAILBOXTP);
        }
    }
}

/* ==================== SEND FUNCTION ==================== */
void SendCANDataTP(uint32_t mailbox, uint32_t messageId, uint8_t *Local_Buff, uint32_t len)
{
    flexcan_data_info_t dataInfo =
    {
        .data_length = (len > 8) ? 8 : len,
        .msg_id_type = FLEXCAN_MSG_ID_STD,
        .enable_brs  = false,
        .fd_enable   = false,
        .fd_padding  = 0U
    };

    FLEXCAN_DRV_ConfigTxMb(INST_CANCOM2, mailbox, &dataInfo, messageId);
    FLEXCAN_DRV_Send(INST_CANCOM2, mailbox, &dataInfo, messageId, Local_Buff);
}

/* ==================== RECEIVE FUNCTION ==================== */
void CAN_receiveTP(const flexcan_msgbuff_t *rxMsg)
{
	if(rxMsg == NULL)
	{
		return;
	}
	/* Blink status LED */
//	    PINS_DRV_SetPins(GPIO_PORT, (1U << LED0));
//	    statusLedTimerTP = STATUS_LED_TIMEOUT_TICKS;

	    printf("RX ID=0x%03lX DLC=%d : ",
	           (unsigned long)rxMsg->msgId,
	           rxMsg->dataLen);

	    for(uint8_t i = 0; i < rxMsg->dataLen; i++)
	    {
	        printf("%02X ", rxMsg->data[i]);
	    }
	    printf("\r\n");
}
//    if(rxMsg == NULL)
//    {
//        return;
//    }
//
//    /* Blink status LED */
//    PINS_DRV_SetPins(GPIO_PORT, (1U << LED0));
//    statusLedTimerTP = STATUS_LED_TIMEOUT_TICKS;
//
//    printf("RX ID=0x%03lX DLC=%d : ",
//           (unsigned long)rxMsg->msgId,
//           rxMsg->dataLen);
//
//    for(uint8_t i = 0; i < rxMsg->dataLen; i++)
//    {
//        printf("%02X ", rxMsg->data[i]);
//    }
//    printf("\r\n");
//
//    /* ---------- FAN ---------- */
//    if(rxMsg->dataLen >= 3 &&
//       rxMsg->data[0] == 'F' &&
//       rxMsg->data[1] == ':')
//    {
//        if(rxMsg->data[2] == '1')
//        {
//            PINS_DRV_SetPins(FAN_LED_PORT, (1U << FAN_LED_PIN));
//        }
//        else
//        {
//            PINS_DRV_ClearPins(FAN_LED_PORT, (1U << FAN_LED_PIN));
//        }
//    }
//
//    /* ---------- HEATER1 ---------- */
//    else if(rxMsg->dataLen >= 4 &&
//            rxMsg->data[0] == 'H' &&
//            rxMsg->data[1] == '1' &&
//            rxMsg->data[2] == ':')
//    {
//        if(rxMsg->data[3] == '1')
//        {
//            PINS_DRV_SetPins(HEATER1_LED_PORT, (1U << HEATER1_LED_PIN));
//        }
//        else
//        {
//            PINS_DRV_ClearPins(HEATER1_LED_PORT, (1U << HEATER1_LED_PIN));
//        }
//    }
//
//    /* ---------- HEATER2 ---------- */
//    else if(rxMsg->dataLen >= 4 &&
//            rxMsg->data[0] == 'H' &&
//            rxMsg->data[1] == '2' &&
//            rxMsg->data[2] == ':')
//    {
//        if(rxMsg->data[3] == '1')
//        {
//            PINS_DRV_SetPins(HEATER2_LED_PORT, (1U << HEATER2_LED_PIN));
//            PINS_DRV_SetPins(HEATER3_LED_PORT, (1U << HEATER3_LED_PIN));
//        }
//        else
//        {
//            PINS_DRV_ClearPins(HEATER2_LED_PORT, (1U << HEATER2_LED_PIN));
//            PINS_DRV_ClearPins(HEATER3_LED_PORT, (1U << HEATER3_LED_PIN));
//        }
//    }
//}

/* ==================== TRANSMIT HARDWARE STATUS ==================== */
//void TransmitHardwareStatusAckTP(uint32_t HW_status)
//{
//    uint8_t txData[8];
//    snprintf((char *)txData, sizeof(txData), "HW1:%lu", HW_status);
//    SendCANDataTP(TX_MAILBOX, TX_MSG_ID, txData, CAN_FRAME_SIZE);
//}
//
///* ==================== UPDATE STATUS LED ==================== */
//void UpdateStatusLEDTP(void)
//{
//    /* Decrement timer if non-zero */
//    if(statusLedTimerTP > 0U)
//    {
//        statusLedTimerTP--;
//
//        /* Turn off LED when timer expires */
//        if(statusLedTimerTP == 0U)
//        {
//            PINS_DRV_ClearPins(GPIO_PORT, (1U << LED0));
//        }
//    }
//}
