SDK/platform/drivers/src/pins/pins_port_hw_access.o: \
 ../SDK/platform/drivers/src/pins/pins_port_hw_access.c \
 ../SDK/platform/drivers/src/pins/pins_port_hw_access.h \
 C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/S32K146_Code/Allygram_ECU1_S32K146/SDK/platform/drivers/inc/pins_driver.h \
 C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/S32K146_Code/Allygram_ECU1_S32K146/SDK/platform/devices/device_registers.h \
 C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/S32K146_Code/Allygram_ECU1_S32K146/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/S32K146_Code/Allygram_ECU1_S32K146/SDK/platform/devices/S32K146/include/S32K146.h \
 C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/S32K146_Code/Allygram_ECU1_S32K146/SDK/platform/devices/S32K146/include/S32K146_features.h \
 C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/S32K146_Code/Allygram_ECU1_S32K146/SDK/platform/devices/devassert.h \
 C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/S32K146_Code/Allygram_ECU1_S32K146/SDK/platform/devices/status.h \
 ../SDK/platform/drivers/src/pins/pins_gpio_hw_access.h

../SDK/platform/drivers/src/pins/pins_port_hw_access.h:

C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/S32K146_Code/Allygram_ECU1_S32K146/SDK/platform/drivers/inc/pins_driver.h:

C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/S32K146_Code/Allygram_ECU1_S32K146/SDK/platform/devices/device_registers.h:

C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/S32K146_Code/Allygram_ECU1_S32K146/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/S32K146_Code/Allygram_ECU1_S32K146/SDK/platform/devices/S32K146/include/S32K146.h:

C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/S32K146_Code/Allygram_ECU1_S32K146/SDK/platform/devices/S32K146/include/S32K146_features.h:

C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/S32K146_Code/Allygram_ECU1_S32K146/SDK/platform/devices/devassert.h:

C:/Users/Public/PEPS_Neelesh/NXP_WORKSPACES/S32K146_Code/Allygram_ECU1_S32K146/SDK/platform/devices/status.h:

../SDK/platform/drivers/src/pins/pins_gpio_hw_access.h:
